#include <Windows.h>

VOID DaemonProcess(HANDLE hand)
{

}